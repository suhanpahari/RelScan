# RelScan — ICDE submission (LaTeX source, v5)

Compile main.tex with pdflatex + bibtex (or latexmk / Overleaf). IEEEtran.cls is included; IEEEtran.bst ships with TeX Live and Overleaf.

- main.tex, preamble.tex (macros and notation)
- sec/       abstract, intro, related work, data model, semantics, OVQL + processing, ingest operators, experiments, conclusion
- tables/    one file per table
- figures_tex/  figure environments (TikZ diagrams, pgfplots charts, image figures)
- figures/   images from the repo assets

Before submission: author block, ICDE AI-use disclosure, artifact link.

v4 (2026-11-04): synced with the repo up to commit a7b4269. See CHANGES.md.
v5 (2026-11-07): renamed OpenSNAP → RelScan. New title: "RelScan: Open-Vocabulary Object Relations for 3D Scans with Query-Time Semantic Cracking". The code repository is still suhanpahari/OpenSNAP.
