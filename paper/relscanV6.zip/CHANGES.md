# v5 → v6 (2026-11-07)
Abstract number fixes (both contradicted the paper's own body and tables; the body was already correct):
- Replica strict instance AP: "21.9 vs. 8.5" → "24.7 vs. 8.5". 24.7 is the dev-chosen SigLIP-so400m row of Tab. compare
  (and matches Sec. 7-B, "on all five on Replica (24.7 vs. 8.5 strict AP)"); 21.9 was the weaker lifted-2D row, and the
  abstract's "better on all five metrics" claim only holds for the 24.7 row.
- OVQL vs phrase embedding on S3DIS: "21.7 vs. 14.3 AP50" → "22.6 vs. 17.7 AP50", matching Tab. relational and Sec. 7
  ("AP50 17.7 vs. 22.6 on S3DIS"). 21.7 / 14.3 appeared nowhere in the paper.
- Project page URL in main.tex: sohamrsch.github.io/opensnap/ → sohamrsch.github.io/relscan/ (the page directory was
  renamed to /relscan, so the old URL 404s).
- Left as-is: the abstract code URL github.com/suhanpahari/opensnap still resolves (GitHub is case-insensitive); update
  it when the code repo is renamed.

# v4 → v5 (2026-11-07)
- Renamed the system OpenSNAP → RelScan (\name macro in preamble.tex, title in main.tex, title strip of figures/outdoor_gallery.jpg). Content unchanged.

# v3 (2026-10-13) → v4 (2026-11-04)

Synced with suhanpahari/OpenSNAP up to a7b4269. Same framing (object database); numbers taken from
results/REVIEW_RESPONSE.md, results/FACADE.md, results/TABLES.md, results/NOVELTY.md and
results/compare/ablate_evidence.json.

## Review-response fixes
- Tab. compare (OVI-MAP protocol): adds measured OVO-SLAM (default 27.4 mIoU; TextRegion + PE-Core 33.4 / 55.0 / 38.7 / 23.8 / 12.4)
  and the dev-chosen SigLIP-so400m row (31.6 / 44.1 / 34.8 / 30.6 / 24.7). All rows of our system now come from one consistent source
  (ablate_evidence.json, dev-chosen setting):
  - geometry only: Replica 18.7/28.5/17.3/15.1/12.9 → 17.5/27.0/18.0/16.0/13.8; ScanNet 14.4/20.4/17.6/14.7/9.8 → 15.1/21.2/18.4/14.0/9.5
  - ScanNet + image SigLIP-L: 25.9/41.2/36.3/29.4/19.9 → 29.9/43.1/39.4/31.3/20.9  ← CHECK: the v3 number had no match in TABLES.md
- Text: OVO-SLAM ahead on semantics / AP25, our system ahead on strict AP; online vs offline and 37 s vs 13.8–24.6 min per scene.
  ScanNet train-scene overlap: equal or better on the 15 val scenes.
- New Tab. ablation: proposals vs image evidence vs decoding, with oracle GT masks.
- Tab. ScanNet200: adds the image-column row (15.3 AP) and Details Matter (25.8).
- Tab. relational regenerated with |B| = 234, plus label-then-filter and vector search + predicates baselines. Text now says
  the ranking gain comes from evaluating query structure (vector search + same NEAR ties it), and that OVQL adds a calibrated probability.
- Background discrepancy: Sec. 4 and the Tab. queries caption say that the workload/latency experiments use |B| = 4 (AP within 1.3 of |B| = 234).
- Calibration: caveat that ECE is over present classes and that P > 0.5 is not a good answer-set rule.
- Related work: BBQ, Details Matter, SAM 3, Chorus (+ bib entries).

## New content
- UnderOneFacade zero-shot study: dataset in setup, Tab. facade, paragraph in Ingest Operators, and a limitations line.
- Discussion: short "Absent concepts and answer sets" paragraph. It reports the pre-registered round-2 membership-head Go
  (ScanNet200 val: 21.8 vs 7.3 cgF1 in 3D, 28.9 vs 19.0 with images). Rounds 3–4 are not included because they are still running.
- Abstract, intro and conclusion updated to match. Image evidence is now SigLIP-so400m (1152-d) in the data-model table.

## To trim length
Shortened: phone-video diagnostics, collapse guard, OpenScan attribute sentence, head-class sentence, conclusion.
The body fits 12 pages; references start on p. 13.
